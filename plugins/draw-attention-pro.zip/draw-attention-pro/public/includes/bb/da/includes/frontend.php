<div class="fl-draw-attention">
	<?php echo do_shortcode( '[drawattention ID=' . $settings->da_img . ']' ); ?>
</div>