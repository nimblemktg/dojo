<div class="hotspots-placeholder" >
	<div class="hotspot-initial">
		<?php 
			if( have_rows('desert_area_cities', 1211) ): $count = 0; while( have_rows('desert_area_cities', 1211) ): the_row(); 
			 	$desert_area_city_list = get_sub_field('desert_area_city_list');
			 	$desert_area_city_list_target = $desert_area_city_list['target'] ? $desert_area_city_list['target'] : '_self';
			 	$icon_image = get_sub_field('icon_image');
				?>
			   <div class="map-area-link hover-bg-<?php echo $count ?>">
					<a href="<?php echo $desert_area_city_list['url']; ?>" class="area-1 area-list" target="<?php echo esc_attr($desert_area_city_list_target); ?>"><img src="<?php echo $icon_image['url']; ?>"><?php echo $desert_area_city_list['title']; ?></a>
			    </div>  
			<?php $count++;  endwhile; endif; 
		?>
	</div>
</div>
<script>
	(function($) {
		setTimeout( function() {
		  $( ".leaflet-zoom-animated g path" ).each(function( index, element ) {
		    $( this ).addClass( "hover-bg-" + index );

		$(".hover-bg-" + index ).mouseenter(function() {
		    $(".hotspots-placeholder .hover-bg-" + index ).css("background", "#52e2f4").css("border-radius", "3px").css("transition", "0.4s");
		})
		$(".hover-bg-" + index ).mouseleave(function() {
		    $(".hotspots-placeholder .hover-bg-" + index ).css("background", "").css("transition", "0.4s");
		});

		$(".hotspot-initial .hover-bg-" + index ).mouseenter(function() {
		    $(".leaflet-zoom-animated .hover-bg-" + index ).css("fill", "#22d8d8").css("fill-opacity", "0.81").css("stroke", "000").css("stroke-opacity", "1.01");
		})
		$(".hotspot-initial .hover-bg-" + index ).mouseleave(function() {
		    $(".leaflet-zoom-animated .hover-bg-" + index ).css("fill", "").css("fill-opacity", "").css("stroke", "").css("stroke-opacity", "");
		});

		  });
		}, 3000);
	})(jQuery);
</script>