<?php

// No hotspots are defined
if ( empty( $settings['hotspots']['0']['coordinates'] ) ) : ?>
	<p><?php _e( 'You need to define some clickable areas for your image.', 'draw-attention' ); ?></p>
	<p><?php echo edit_post_link( __( 'Edit Image', 'draw-attention' ), false, false, $settings['image_id'] ); ?></p>

<?php // In page builder edit mode - just display the image ?>
<?php elseif ( !empty( $_GET['fl_builder'] ) || !empty( $_GET['elementor-preview'] ) || ( !empty( $_GET['action'] ) && $_GET['action'] == 'elementor' ) ): ?>
	<div class="hotspots-image-container">
		<img
			width="<?php echo $settings['img_width']; ?>"
			height="<?php echo $settings['img_height']; ?>"
			src="<?php echo $settings['img_url']; ?>"
			alt="<?php echo $settings['img_alt']; ?>"
			class="hotspots-image skip-lazy"
			data-id="<?php echo $settings['image_id']; ?>"
			data-no-lazy="1"
			data-lazy="false"
			>
	</div>
<?php // There are hotspots! Show the interactive image ?>
<?php else : ?>

<style>
	#<?php echo $settings['spot_id']; ?> .hotspots-image-container,
	#<?php echo $settings['spot_id']; ?> .leaflet-container {
		background: <?php echo $settings['img_bg']; ?>
	}

	#<?php echo $settings['spot_id']; ?> .hotspots-placeholder {
		background: <?php echo $settings['more_info_bg']; ?>;
		border: 0 <?php echo $settings['more_info_bg']; ?> solid;
		color: <?php echo $settings['more_info_text']; ?>;
	}

	#<?php echo $settings['spot_id']; ?> .hotspot-title {
		color: <?php echo $settings['more_info_title']; ?>;
	}

	<?php foreach ($formatted_styles as $style) : ?>
		#<?php echo $settings['spot_id']; ?> .hotspot-<?php echo $style['name']; ?> {
			stroke-width: <?php echo $style['borderWidth']; ?>;
			fill: <?php echo $style['display']['fillColor']; ?>;
			fill-opacity: <?php echo $style['display']['fillOpacity']; ?>;
			stroke: <?php echo $style['display']['borderColor']; ?>;
			stroke-opacity: <?php echo $style['display']['borderOpacity']; ?>;
		}
		#<?php echo $settings['spot_id']; ?> .hotspot-<?php echo $style['name']; ?>:hover,
		#<?php echo $settings['spot_id']; ?> .hotspot-<?php echo $style['name']; ?>.hotspot-active {
			fill: <?php echo $style['hover']['fillColor']; ?>;
			fill-opacity: <?php echo $style['hover']['fillOpacity']; ?>;
			stroke: <?php echo $style['hover']['borderColor']; ?>;
			stroke-opacity: <?php echo $style['hover']['borderOpacity']; ?>;
		}
	<?php endforeach; ?>
	#<?php echo $settings['spot_id']; ?> .leaflet-tooltip,
	#<?php echo $settings['spot_id']; ?> .leaflet-rrose-content-wrapper {
		background: <?php echo $settings['more_info_bg']; ?>;
		border-color: <?php echo $settings['more_info_bg']; ?>;
		color: <?php echo $settings['more_info_text']; ?>;
	}

	#<?php echo $settings['spot_id']; ?> a.leaflet-rrose-close-button {
		color: <?php echo $settings['more_info_title']; ?>;
	}

	#<?php echo $settings['spot_id']; ?> .leaflet-rrose-tip {
		background: <?php echo $settings['more_info_bg']; ?>;
	}

	#<?php echo $settings['spot_id']; ?> .leaflet-popup-scrolled {
		border-bottom-color: <?php echo $settings['more_info_text']; ?>;
		border-top-color: <?php echo $settings['more_info_text']; ?>;
	}

	#<?php echo $settings['spot_id']; ?> .leaflet-tooltip-top:before {
		border-top-color: <?php echo $settings['more_info_bg']; ?>;
	}

	#<?php echo $settings['spot_id']; ?> .leaflet-tooltip-bottom:before {
		border-bottom-color: <?php echo $settings['more_info_bg']; ?>;
	}
	#<?php echo $settings['spot_id']; ?> .leaflet-tooltip-left:before {
		border-left-color: <?php echo $settings['more_info_bg']; ?>;
	}
	#<?php echo $settings['spot_id']; ?> .leaflet-tooltip-right:before {
		border-right-color: <?php echo $settings['more_info_bg']; ?>;
	}
</style>

<?php /*
<script>
	window.daStyles<?php echo $settings['image_id']; ?> = <?php echo json_encode($formatted_styles); ?>
</script>
*/ ?>

	<div class="hotspots-container <?php echo $settings['urls_class']; ?> layout-<?php echo $settings['layout']; ?> event-<?php echo $settings['event_trigger']; ?>" id="<?php echo $settings['spot_id']; ?>" data-layout="<?php echo $settings['layout']; ?>" data-trigger="<?php echo $settings['event_trigger']; ?>">
		<div class="hotspots-interaction">
			<?php if ( $settings['urls_only'] ) {
				require( $this->get_plugin_dir() . '/public/views/image_template.php' );
				require( $this->get_plugin_dir() . '/public/views/more_info_template.php' );
			} else  {
				require( $this->get_plugin_dir() . '/public/views/image_template.php' );
				require( $this->get_plugin_dir() . '/public/views/more_info_template.php' );
			} ?>
		</div>
		<map name="hotspots-image-<?php echo $settings['image_id']; ?>" class="hotspots-map">
			<?php foreach( $settings['hotspots'] as $key => $hotspot ) : ?>
				<?php
					$coords = $hotspot['coordinates'];
					$target = !empty( $hotspot['action'] ) ? $hotspot['action'] : '';
					$new_window = !empty( $hotspot['action-url-open-in-window'] ) ? $hotspot['action-url-open-in-window'] : '';
					$target_window = $new_window == 'on' ? '_new' : '';
					$target_url = !empty( $hotspot['action-url-url'] ) ? $hotspot['action-url-url'] : '';
					$area_class = $target == 'url' ? 'url-area' : 'more-info-area';
					$href = $target == 'url' ? $target_url : '#hotspot-' . $settings['spot_id'] . '-' . $key;
					$href = !empty($href) ? $href : '#';
					$title = !empty( $hotspot['title'] ) ? $hotspot['title'] : '';
					if ( empty( $hotspot['description'] ) ) {
						$hotspot['description'] = '';
					}
					if ( empty( $settings['img_settings']['_da_has_multiple_styles']['0'] ) || $settings['img_settings']['_da_has_multiple_styles']['0'] != 'on' || empty( $hotspot['style'] ) ) {
						$color_scheme = '';
					} else {
						$color_scheme = $hotspot['style'];
					}

				?>
				<area
					shape="poly"
					coords="<?php echo $coords; ?>"
					href="<?php echo $href; ?>"
					title="<?php echo $title; ?>"
					alt="<?php echo $title; ?>"
					data-action="<?php echo $target; ?>"
					data-color-scheme="<?php echo $color_scheme; ?>"
					target="<?php echo $target_window; ?>"
					class="<?php echo $area_class; ?>"
					>
			<?php endforeach; ?>
		</map>
			<div class="hotspot-info <?php echo $color_scheme_class; ?>" id="hotspot-<?php echo $settings['spot_id']; ?>-<?php echo $key; ?>">
				
			</div>
	</div>

<?php endif; ?>