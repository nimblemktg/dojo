# Hide form after submitting

To hide the form after it was submitted by the user, you can go to `Form Settings > Form Settings`.

Enable the option **Hide form after submitting**.

When enabled, the form will fade out as soon as the form was successfully submitted by the user.

?> **Please note:** The success message will still appear if the success message is enabled

