# Spacer element

This element is solely for creating vertical spaces between elements in your form!